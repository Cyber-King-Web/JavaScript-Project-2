let inbox = document.getElementById('inbox');
let btn = document.getElementById('btn');
let containt = document.getElementById('containt');


function getdata() {
	let valuee = inbox.value;
	// console.log(valuee);

	let pare = document.createElement('p');
	let pareValue = pare.innerText = valuee;

	containt.append(pare);

	inbox.value = "";

}


containt.addEventListener('click', (Event) => {
	let rem = Event.target;

	rem.remove(rem)
})


btn.addEventListener('click', () => {
	getdata()
})