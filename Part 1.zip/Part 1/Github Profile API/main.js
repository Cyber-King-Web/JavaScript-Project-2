let btn = document.querySelector('.btn');
let image = document.querySelector('.img');
let nameFull = document.querySelector('.name');
let userName = document.querySelector('.username');
let companyname = document.querySelector('.compny');
let follower = document.querySelector('.followerdata');
let followings = document.querySelector('.followingdata');
let repoLink = document.querySelector('.reclick');
let socialMedia = document.querySelector('.soclick');
let locationData = document.querySelector('.location');
let input = document.querySelector('.inptext');

let inputData = '';

const getUserData = async (data) => {
	let apiURL = `https://api.github.com/users/${data}`;

	const res = await fetch(apiURL);
	const dataFill = await res.json();

	const { avatar_url, company, followers, following, location, login, name, html_url, twitter_username } = dataFill;

	image.src = avatar_url;
	companyname.innerHTML = company;
	follower.innerHTML = followers;
	followings.innerHTML = following;
	repoLink.href = html_url;
	socialMedia.href = `https://twitter.com/${twitter_username}`;
	locationData.innerHTML = location;
	nameFull.innerHTML = name;
	userName.innerHTML = `@${login}`;
}

btn.addEventListener('click', (e) => {
	e.preventDefault()
	inputData = input.value;
	if (inputData.length === 0) {
		alert("Enter User Name")
	} else {
		getUserData(inputData)
	}

})

getUserData('Cyber-King-Web');