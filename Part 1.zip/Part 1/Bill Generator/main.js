let inputName = document.getElementById('name');
let inputEmail = document.getElementById('email');
let samosa = document.getElementById('samosa');
let burgur = document.getElementById('burgur');
let nameOUT = document.getElementById('nameOut');
let emailOUT = document.getElementById('emailOut');
let table = document.getElementById('table');
let totalll = document.getElementById('total');

let barger_total;
let samosa_total;

let samosa_price = 5,
	bargur_price = 20;

let samosabill = '',
	burgurbill = '';

inputName.addEventListener('keyup', () => {
	let name = inputName.value;
	nameOUT.innerText = name;
})
inputEmail.addEventListener('keyup', () => {
	let email = inputEmail.value;
	emailOUT.innerText = email;
})

samosa.addEventListener('keyup', () => {
	let samQ = samosa.value;
	samosa_total = samosa_price * samQ;

	if (samQ == "" || samQ == 0) {
		samosabill = '';
		showbill();
	} else {
		samosabill = `<tr><td>samosa</td><td>${samosa_price}</td><td>${samQ}</td><td>${samosa_total}</td></tr>`
		showbill();
		total()
	}
})


burgur.addEventListener('keyup', () => {
	let barQ = burgur.value;
	barger_total = bargur_price * barQ;

	if (barQ == "" || barQ == 0) {
		burgurbill = "";
		showbill()
	} else {
		burgurbill = `<tr><td>barger</td><td>${bargur_price}</td><td>${barQ}</td><td>${barger_total}</td></tr>`
		showbill()
		total()
	}
})

function total() {
	let totalShow = samosa_total + barger_total;
	totalll.innerText = totalShow;

}

function showbill() {
	table.innerHTML = samosabill + burgurbill;
}