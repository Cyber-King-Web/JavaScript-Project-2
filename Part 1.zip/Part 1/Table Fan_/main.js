let onBtn = document.querySelector('.btn1');
let offBtn = document.querySelector('.btn2');
let btn1 = document.querySelector('.btn3');
let btn2 = document.querySelector('.btn4');
let btn3 = document.querySelector('.btn5');
let fan = document.getElementById('fan_img')


onBtn.addEventListener('click', () => {
	fan.style.animationDuration = 3 + 's';
})
offBtn.addEventListener('click', () => {
	fan.style.animationDuration = 0 + 's';
})
btn1.addEventListener('click', () => {
	fan.style.animationDuration = 1 + 's';
})
btn2.addEventListener('click', () => {
	fan.style.animationDuration = 0.5 + 's';
})
btn3.addEventListener('click', () => {
	fan.style.animationDuration = 0.1 + 's';
})