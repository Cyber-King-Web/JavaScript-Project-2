let btn1 = document.getElementById('btn1');
let btn2 = document.getElementById('btn2');
let btn3 = document.getElementById('btn3');
let btn4 = document.getElementById('btn4');
let codeText = document.getElementById('color_code');

let hex1 = '#004d7a';
let hex2 = '#008793';
let hex3 = '#00bf72';
let hex4 = '#a8eb12';


const getHexCode = () => {
	let hexValue = '0123456789abcdef';
	let color = "#";
	for (var i = 0; i < 6; i++) {
		color = color + hexValue[Math.floor(Math.random() * 16)];
	}
	console.log(color);
	return color;
}


const hexColor1 = () => {
	hex1 = getHexCode();
	btn1.innerText = hex1;
	btn1.style.backgroundColor = hex1;
	document.body.style.backgroundImage = `linear-gradient(to right top, ${hex1}, ${hex2}, ${hex3}, ${hex4})`;
	codeText.innerText = `background-image: linear-gradient(to right top, ${hex1}, ${hex2}, ${hex3}, ${hex4})`;
}
const hexColor2 = () => {
	hex2 = getHexCode();
	btn2.innerText = hex2;
	btn2.style.backgroundColor = hex2;
	document.body.style.backgroundImage = `linear-gradient(to right top, ${hex1}, ${hex2}, ${hex3}, ${hex4})`;
	codeText.innerText = `background-image: linear-gradient(to right top, ${hex1}, ${hex2}, ${hex3}, ${hex4})`;
}
const hexColor3 = () => {
	hex3 = getHexCode();
	btn3.innerText = hex3;
	btn3.style.backgroundColor = hex3;
	document.body.style.backgroundImage = `linear-gradient(to right top, ${hex1}, ${hex2}, ${hex3}, ${hex4})`;
	codeText.innerText = `background-image: linear-gradient(to right top, ${hex1}, ${hex2}, ${hex3}, ${hex4})`;
}
const hexColor4 = () => {
	hex4 = getHexCode();
	btn4.innerText = hex4;
	btn4.style.backgroundColor = hex4;
	document.body.style.backgroundImage = `linear-gradient(to right top, ${hex1}, ${hex2}, ${hex3}, ${hex4})`;
	codeText.innerText = `background-image: linear-gradient(to right top, ${hex1}, ${hex2}, ${hex3}, ${hex4})`;
}


btn1.addEventListener('click', hexColor1);
btn2.addEventListener('click', hexColor2);
btn3.addEventListener('click', hexColor3);
btn4.addEventListener('click', hexColor4);

/* Copy Text */
codeText.addEventListener('click', () => {
	navigator.clipboard.writeText(codeText.innerText);
	alert("Copied the text: " + codeText.innerText);
})