let input = document.getElementById('input');
let btn = document.getElementById('btn');
let city = document.getElementById('city');
let weatherShow = document.getElementById('weather');
let times = document.getElementById('times');
let img = document.getElementById('image')
let temp = document.getElementById('temp');
let min = document.getElementById('min');
let max = document.getElementById('max');
let feel = document.getElementById('feel');
let humidity = document.getElementById('humidity');
let winds = document.getElementById('wind');
let pressure = document.getElementById('pressure');

let cityValue = 'deoria';



// get country full name
const fullCountryName = (data) => {
	const regionNamesInEnglish = new Intl.DisplayNames(['en'], { type: 'region' });
	return regionNamesInEnglish.of(data);
}



/* get time */
const getTime = (data) => {
	const currDate = new Date(data * 1000)
	const opt = {
		weekday: 'long',
		year: 'numeric',
		month: 'long',
		day: 'numeric',
		hour: 'numeric',
		minute: 'numeric',
	};
	const formater = new Intl.DateTimeFormat('en-US', opt)
	return formater.format(currDate)
};



/* search functionality */
btn.addEventListener('click', () => {
	cityValue = input.value
	getAPIdata();
	input.value = '';
})



//  get api data 
const getAPIdata = async () => {

	const apiURL = `https://api.openweathermap.org/data/2.5/weather?q=${cityValue}&appid=1e8bc9dfd430c36027407f2ccc904779`

	try {
		const response = await fetch(apiURL);
		const data = await response.json();
		const { main, sys, name, weather, wind, dt } = data;

		city.innerText = `${name}, ${fullCountryName(sys.country)}`;
		times.innerHTML = getTime(dt);
		weatherShow.innerHTML = weather[0].main;
		img.innerHTML = `<img src="http://openweathermap.org/img/wn/${weather[0].icon}@2x.png">`;
		temp.innerHTML = `${main.temp}&#176`;
		min.innerHTML = `Min: ${main.temp_min.toFixed()}&#176`;
		max.innerHTML = `Max: ${main.temp_max.toFixed()}&#176`;
		feel.innerHTML = `${main.feels_like.toFixed()}&#176`;
		humidity.innerHTML = `${main.humidity}%`
		winds.innerHTML = `${wind.speed} m/s`
		pressure.innerHTML = `${main.pressure} hPa`

	} catch (e) {
		console.log(e)
	}

}

document.addEventListener('load', getAPIdata());