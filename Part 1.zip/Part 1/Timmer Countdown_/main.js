let start = document.getElementById('btn1');
let stopbtn = document.getElementById('btn2');
let reset = document.getElementById('btn3');
let getTime = document.getElementById('btn4');
let clear = document.getElementById('btn5');

let display = document.getElementById('screen');
let display2 = document.querySelector('.display2');


let countTime = 0;
let intravalId;

const timeStart = () => {
	intravalId = setInterval(() => {
		display.innerText = countTime++;
	}, 1000);
}

const timeStop = () => {
	timeGet();
	clearInterval(intravalId);
}

const timeReset = () => {
	countTime = 0;
	display.innerText = countTime;
	clearInterval(intravalId);
}

const timeGet = () => {
	let para = document.createElement('p');
	para.innerText = `stop tine ${countTime - 1}`;
	display2.append(para);
}

const timeClear = ()=>{
	display2.innerHTML = '';
}


start.addEventListener('click', timeStart);
stopbtn.addEventListener('click', timeStop);
reset.addEventListener('click', timeReset);
getTime.addEventListener('click', timeGet);
clear.addEventListener('click', timeClear);