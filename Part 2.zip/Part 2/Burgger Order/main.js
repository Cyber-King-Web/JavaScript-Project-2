let headerImage = document.querySelector('.headimg');
let images = document.querySelectorAll('.bottom .imgdiv img');


images.forEach((img) => {
	img.addEventListener('click', () => {
		let url = img.src;
		headerImage.src = url;
	})
})