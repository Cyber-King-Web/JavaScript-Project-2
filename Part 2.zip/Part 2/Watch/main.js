let timer = document.getElementById('timer');




// color chande function 
function getColor() {

	let red = Math.floor(Math.random() * 256);
	let green = Math.floor(Math.random() * 256);
	let blue = Math.floor(Math.random() * 256);

	return `rgb(${red}, ${green}, ${blue})`

}

setInterval(() => {
	let colorChange = getColor();
	// console.log(colorChange)
	timer.style.color = colorChange;


}, 1000);


/* change time */
function timeChange() {
	let date = new Date();
	let time = date.toLocaleTimeString();
	// console.log(time)
	timer.innerText = time;
}

setInterval(timeChange, 1000);