let inputText = document.querySelector('.input');
let btn = document.querySelector('.btn');

btn.addEventListener('click', (e) => {
	e.preventDefault();
	let text = inputText.value;
	btn.innerHTML = 'downloading file...'
	getData(text);
})


const getData = async (url) => {

	const res = await fetch(url);
	const file = await res.blob();
	let tempUrl = URL.createObjectURL(file);

	let aTag = document.createElement('a');
	aTag.href = tempUrl;
	aTag.download = url.replace(/^.*[\\\/]/, '');
	document.body.appendChild(aTag);
	aTag.click();
	aTag.remove();

	btn.innerHTML = 'download file';
	URL.revokeObjectURL(tempUrl);

}