let amount = document.getElementById('amount_input');
let tip = document.getElementById('tip_input');

let btn = document.querySelector('.button');

let totalTip = document.getElementById('tip');
let totalAmount = document.getElementById('total');


btn.addEventListener('click', () => {
	let getAmount = amount.value;
	let getTipAmount = tip.value;

	let getTotalTip = getAmount * (getTipAmount / 100);

	totalTip.innerText = getTotalTip.toFixed(2);

	totalAmount.innerText = getTotalTip + Number(getAmount);

})