let text = document.getElementById('colortext');
let btn = document.getElementById('btn');


function getColor() {

	let red = Math.floor(Math.random() * 255);
	let green = Math.floor(Math.random() * 255);
	let blue = Math.floor(Math.random() * 255);

	return `rgb(${red}, ${green}, ${blue})`

}

btn.addEventListener('click', () => {
	let colorChange = getColor();
	text.innerText = colorChange;
	document.body.style.backgroundColor = colorChange;

})

  