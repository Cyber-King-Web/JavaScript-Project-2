let code = document.querySelector('.lat-long');
let btn = document.querySelector('.btn');
let fullAdd = document.querySelector('.full_add');
let forAdd = document.querySelector('.formated');


const getUserLocation = async (latitude, longitude) => {
	let apiKey = 'bd0ffea09ca94c38b7aec298cbce3048';
	let urlEndPoint = `https://api.opencagedata.com/geocode/v1/json?key=${apiKey}&q=${latitude}%2C+${longitude}&pretty=1`;

	const res = await fetch(urlEndPoint);
	const data = await res.json();
	let { country, postcode, road, state, county } = data.results[0].components;

	fullAdd.innerHTML = `${road}, ${county}, ${state}, ${country}, ${postcode}`;
	forAdd.innerHTML = data.results[0].formatted;

}

btn.addEventListener('click', () => {
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition((position) => {

			const { latitude, longitude } = position.coords;
			code.innerHTML = `latitude : ${latitude} & longitude : ${longitude}`;
			getUserLocation(latitude, longitude);

		}, (error) => {
			code.innerHTML = error.message;
		})
	}
})