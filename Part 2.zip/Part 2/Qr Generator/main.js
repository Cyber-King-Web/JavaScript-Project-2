let genBtn = document.querySelector('.btn_gen');
let downBtn = document.querySelector('.btn_down');
let container = document.querySelector('.container')
let img = document.querySelector('.img');
let text = document.querySelector('.inptext');




genBtn.addEventListener('click', () => {
	let qrValue = text.value;
	if (!qrValue) return;
	genBtn.innerHTML = 'Generating Qr Code...';
	img.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${qrValue}`;

	img.addEventListener('load', () => {
		genBtn.innerHTML = 'Generate Qr Code';
		container.classList.add('active');
	})

})

text.addEventListener("keyup", () => {
	if (!text.value) {
		container.classList.remove('active');
	}
})

/* downloading Function ⬇️  */

downBtn.addEventListener('click', (e) => {
	e.preventDefault()
	let imagelink = img.src;
downBtn.innerHTML='Downloading'
	getDownload(imagelink)

})


const getDownload = async (url) => {

	const res = await fetch(url);
	const file = await res.blob();
	let tempUrl = URL.createObjectURL(file);

	let aTag = document.createElement('a');
	aTag.href = tempUrl;
	aTag.download = url.replace(/^.*[\\\/]/, '');
	document.body.appendChild(aTag);
	aTag.click();
	aTag.remove();

	downBtn.innerHTML = 'Download';
	URL.revokeObjectURL(tempUrl);

}