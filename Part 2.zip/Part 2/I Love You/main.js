let yes = document.getElementById('yesbtn');
let no = document.getElementById('nobtn');
let textpara = document.querySelector('.text');
let sms = '❤️ love you too ❤️';

yes.addEventListener('click', () => {
	textpara.innerText = sms;
	
	confetti();
	
confetti({
	particleCount: 100,
	spread: 70,
	origin: { y: 0.6 }
});
	
})



function moveTarget() {
	const maxWidth = 400;
	const maxHeight = 400;

	const ranomX = Math.floor(Math.random() * maxWidth);
	const ranomY = Math.floor(Math.random() * maxHeight);

	no.style.left = ranomX + 'px';
	no.style.top = ranomY + 'px';

}

no.addEventListener('mouseenter', function() {
	moveTarget();
	// console.log("hello")
})
